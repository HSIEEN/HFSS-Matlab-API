% Description:
% ------------
% A simple example to demonstrate the HFSS-MATLAB-API. This script
% optimizes a dipole antenna design to resonate at a specified frequency.
% The initial length of the dipole is taken to be half the wavelength and
% is optimized so that the simulated resonance frequency and the desired
% resonance frequency are close.

clc; clear variables; close all;

% Add paths to the required m-files.
% Add paths to the required m-files.
addpath('C:\Program Files\MATLAB\R2014a\bin\hfss-api-master\');

% manually add the API root directory.
hfssIncludePaths('C:\Program Files\MATLAB\R2014a\bin\hfss-api-master\');
Dir='C:\SimDirect\HFSS\Perturbation';
PrjFile     = [Dir, '\Perturbation-Rectanglar.hfss'];
%DataFile   = [Direct, '\tmpData.m'];
CsvFile     = [Dir, '\tmpCsv.csv'];
ScriptFile  = [Dir, '\Perturbation-Rectanglar.vbs'];
% HFSS Executable Path.
hfssExePath = 'C:\Program Files\AnsysEM\HFSS15.0\Win64\hfss.exe';
delete([Dir, '\*.lock']);
delete([Dir, '\*.auto']);
delete([Dir, '\*.csv']);

%Set deisign parameters
DesignName = 'PostTC105';
SetupName = 'Setup1';
Variable = 'Hmpost';
Max = 14;
Min = 6;
PlotName = 'S12Plot';
ModName = 'Sheet';
% parameters for traversal optimization
%length range
TVariable = 'Hcp';
VRange = [10,16];
% target S11 value
GoalValue = -15;
%Sample materials cell
Material={'vacuum','Teflon (tm)','Krempel Akaflex PCL (tm)','FR4_epoxy',...
    'Rogers TMM 4 (tm)','Rogers TMM 6 (tm)'};
OValue = zeros(length(Material),1);
OLen = zeros(length(Material),1);
OMag = zeros(length(Material),1);
Ofreq = zeros(length(Material),1);
%Resonance frequecny before tunning any parameter
Nfreq = zeros(length(Material),1);
%accuracy requirement of interpolation algorithm
Accuracy = 8e-5;

%material is vacuum
fprintf('######  The Material is %s  ######\n', Material{1});
disp('Simulation running without optimizing.....');
[Nfreq(1,1),dBmag] = HFSS(ScriptFile,hfssExePath,...
    PrjFile,DesignName,SetupName,Variable,Min,ModName,...
    Material{1},PlotName,CsvFile );
    % delele the tmpcsv file
if dBmag < GoalValue
    fprintf('The resonance frequency of empty cavity is: %.4f GHz\n',...
        Nfreq(1,1));
    fprintf('and the magnitude is: %.3f dB\n',...
        dBmag);
    copyfile(CsvFile,[Dir,'\SimulatedData\',...
        'Empty.csv']);
    delete([Dir, '\*.csv']);
    % delele the tmpcsv file
    Ofreq(1,1) = Nfreq(1,1);
    
    OValue(1,1) = Min;
else
    disp('The required goal Not met, Optimization loop will run.');
    disp('Optimizing the matching status with Traversal algorithm.......');
    [hasConverged,OLen(1,1),Ofreq(1,1),OMag(1,1)] = Traversal(ScriptFile,...
        hfssExePath,PrjFile,DesignName,SetupName,...
        TVariable,VRange,GoalValue,PlotName,CsvFile,ModName, Material{1});
    if hasConverged
        fprintf('The resonance frequency of empty cavity is: %.4f GHz\n',...
            Ofreq(1,1));
        fprintf('and the magnitude is: %.3f dB\n',...
            OMag(1,1));
        copyfile(CsvFile,[Dir,'\SimulatedData\',...
            'Empty.csv']);
        % delele the tmpcsv file
        delete([Dir, '\*.csv']);
        OValue(1,1) = Min;
    end
end

for iMaterial=2:length(Material)
    fprintf('\n');
    %Set varibles of interpolation search
    fprintf('######  The Material is %s  ######\n', Material{iMaterial});
    
    disp('Running simulation before tunning the resonance frequecy...');
    
    [Nfreq(iMaterial,1),~] = HFSS(ScriptFile,hfssExePath,...
        PrjFile,DesignName,SetupName,Variable,Min,ModName,...
        Material{iMaterial},PlotName,CsvFile );
    fprintf('The resonance frequency before tunning is %.4f GHz.\n',...
        Nfreq(iMaterial,1));
    % copy the tmpcsv file to the target directory and rename it
    copyfile(CsvFile,[Dir,'\SimulatedData\',...
        'No-retunning_',Material{iMaterial},'.csv']);
    % delele the tmpcsv file
    delete([Dir, '\*.csv']);
    
    disp('Tunning the resonance frequency with interpolation algorithm...');
    [hasConverged,OValue(iMaterial,1)] = Interpolation(ScriptFile,...
        hfssExePath,PrjFile,DesignName,SetupName,Variable,[Min,Max],...
        Ofreq(1,1),Accuracy,PlotName,CsvFile,ModName,Material{iMaterial});
    if hasConverged == true
        copyfile(CsvFile,[Dir,'\SimulatedData\',...
            'Retunning_',Material{iMaterial},'.csv']);
        delete([Dir, '\*.csv']);
    end
    %Traversal optimization
    disp('Tunning the matching status with Traversal algorithm...');
    [hasConverged,OLen(iMaterial,1),Ofreq(iMaterial,1),OMag(iMaterial,1)] =...
        Traversal(ScriptFile,hfssExePath,PrjFile,DesignName,SetupName,...
        TVariable,VRange,GoalValue,PlotName,CsvFile,ModName, Material{iMaterial});
    if hasConverged == true
        copyfile(CsvFile,[Dir,'\SimulatedData\',...
            'RetunnCoulpling_',Material{iMaterial},'.csv']);
        delete([Dir, '\*.csv']);
    end
end

csvwrite([Dir,'\SimulatedData\OValues.csv'],[Nfreq,OValue,Ofreq,OLen]);

disp('');
disp('');

% Remove all the added paths.
hfssRemovePaths('C:\Program Files\MATLAB\R2014a\bin\hfss-api-master\');
rmpath('C:\Program Files\MATLAB\R2014a\bin\hfss-api-master\');