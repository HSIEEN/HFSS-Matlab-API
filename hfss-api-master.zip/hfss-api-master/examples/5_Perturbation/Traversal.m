function [hasConverged,OValue,Rfreq,OMag] =...
    Traversal(ScriptFile,hfssExePath,PrjFile,DesignName,SetupName,...
    Variable,VRange,GoalValue,PlotName,CsvFile,ModName,Material)
%Optimization the Vararibale within range of VRange
%The goalValue is db value of S11 at resonance frequency
%Parameters
%@Variable: variable to be optimized
%@VRange: variable range to be optimized in
%@GoalVar: objective variable
%@GoalValue: value of objective variable
% Optimization stop conditions.
hasConverged = false;     % converge status
% set maximum and minimum value of variable to be optimized
DownLimit = 0;
UpLimit = 24;

Min = VRange(1,1);
Max = VRange(1,2);
fprintf('### The loop will run in the range of %.3f mm to %.3f mm ###.\n',...
    Min,Max);
Step = 6;
Var = linspace(Min,Max,Step)';
StepSize = (Max-Min)/Step;
Rf = zeros(Step,1);
dBmag = zeros(Step,1);

Dir = 'C:\SimDirect\HFSS\Perturbation';

for iIters = 1:Step
    
    fprintf('Running traversal step #%d.........\n', iIters);
    fprintf(['The new estimated value of ',Variable,' is %.3f mm\n'],...
        Var(iIters,1));
    try
        [Rf(iIters,1),dBmag(iIters,1)] = HFSS(ScriptFile,hfssExePath,...
            PrjFile,DesignName,SetupName,Variable,Var(iIters,1),...
            ModName,Material,PlotName,CsvFile );
    catch
        
        continue;
    end
    fprintf('Simulated Resonance Frequency: %.4f GHz\n', Rf(iIters,1));
    fprintf('Simulated magnitude: %.4f dB\n', dBmag(iIters,1));
    if dBmag(iIters,1) < GoalValue
        
        break;
    end
    %Reach the extreme value
    if iIters > 2 && (dBmag(iIters,1)-dBmag(iIters-1,1))*...
            (dBmag(iIters-1,1)-dBmag(iIters-2,1))< 0
        break;
    end
    % update Var(iIters+1,1)
    if Var(iIters,1) == Max
        break;
    else
        if (GoalValue - dBmag(iIters,1)) < -10
            Var(iIters+1,1) = Var(iIters,1) + 2*StepSize;
            if Var(iIters+1,1) > Max
                Var(iIters+1,1) = Max;
            end
        elseif (GoalValue - dBmag(iIters,1)) < -8
            Var(iIters+1,1) = Var(iIters,1) + 1.5*StepSize;
            if Var(iIters+1,1) > Max
                Var(iIters+1,1) = Max;
            end
        elseif (GoalValue - dBmag(iIters,1)) < -5
            Var(iIters+1,1) = Var(iIters,1) + StepSize;
            if Var(iIters+1,1) > Max
                Var(iIters+1,1) = Max;
            end
        elseif (GoalValue - dBmag(iIters,1)) >= -5
            Var(iIters+1,1) = Var(iIters,1) + 0.5*StepSize;
            if Var(iIters+1,1) > Max
                Var(iIters+1,1) = Max;
            end
        end
    end
end

[minValue,minIndex] = min(dBmag);

fprintf(...
    'Loop running done, the minimum value of S11 is %.3fdB @ %.4f GHz.\n',...
    minValue,Rf(minIndex,1));
% Check if the required goal is met.

if minValue < GoalValue
    disp('Required Goal is met!');
    fprintf('Optimized Variable is %.3f mm.\n', Var(minIndex,1));
    hasConverged = true;
    %copyfile(CsvFile,[Dir,'\SimulatedData\',...
    %    'RetunnCoulpling_',Material,'.csv']);
    %delete([Dir, '\*.csv']);
    OValue = Var(minIndex,1);
    OMag = minValue;
    Rfreq = Rf(minIndex,1);
else
    %Scale factor
    Kf = abs(minValue-GoalValue)/5;
    if minIndex ~= 1 && minIndex ~= Step
        %if the extreme value is between min and max,update range
        VRange = [max(Var(minIndex,1)-Kf,DownLimit),...
            min(Var(minIndex,1)+Kf,UpLimit)];
        if VRange(1,1) == Min && VRange(2,1) == Max
            VRange = [Min+0.5,Max-0.5];
        end
        [hasConverged,OValue,Rfreq,OMag] = Traversal(ScriptFile,...
            hfssExePath,PrjFile,DesignName,SetupName,...
            Variable,VRange,GoalValue,PlotName,CsvFile,ModName,Material);
        
    elseif minIndex == 1 && Var(minIndex,1) ~= DownLimit
        %if the extreme value is the minimumvalue and no the downlimit
        VRange = [max(Var(minIndex,1)-1.5*Kf,DownLimit),...
            min(Var(minIndex,1),UpLimit)];
        if VRange(1,1) == Min && VRange(2,1) == Max
            VRange = [Min+0.5,Max-0.5];
        end
        [hasConverged,OValue,Rfreq,OMag] = Traversal(ScriptFile,...
            hfssExePath,PrjFile,DesignName,SetupName,...
            Variable,VRange,GoalValue,PlotName,CsvFile,ModName,Material);
        if OMag < GoalValue
            hasConverged = true;
        end
        
    elseif minIndex == Step && Var(minIndex,1) ~=UpLimit
        %if the extreme value is the maximumvalue and no the uplimit
        VRange = [max(Var(minIndex,1),DownLimit),...
            min(Var(minIndex,1)+1.5*Kf,UpLimit)];
        if VRange(1,1) == Min && VRange(2,1) == Max
            VRange = [Min+0.5,Max-0.5];
        end
        [hasConverged,OValue,Rfreq,OMag] = Traversal(ScriptFile,...
            hfssExePath,PrjFile,DesignName,SetupName,...
            Variable,VRange,GoalValue,PlotName,CsvFile,ModName,Material);
        if OMag < GoalValue
            hasConverged = true;
        end
    elseif Var(minIndex,1) == DownLimit || Var(minIndex,1) == UpLimit
        
    end
    
end
%DataFile = [Direct, '\tmpData', num2str(iIters), '.m'];
% The data items are in the f, S, Z variables now.
% Plot the data.
%disp('Solution Completed. Plotting Results for this iteration...');
%figure(1);
%hold on; grid on;
% plot(f/1e9, LomgS, pltCols(mod(iIters, nCols) + 1));
%hold on;
%xlabel('Frequency (GHz)');
%ylabel('S_{12} (dB)');
%axis([fLow/1e9, fHigh/1e9, -50, 0]);
if (~hasConverged)
    disp('Max Steps exceeded. Optimization did NOT converge .....');
    %fprintf('...The current  #%d...\n', iIters);
    delete([Dir, '\*.csv']);
end

disp('');
disp('');

end