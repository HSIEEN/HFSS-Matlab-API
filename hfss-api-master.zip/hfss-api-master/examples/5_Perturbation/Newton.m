function [hasConverged,OValue,Rfreq,OMag] =...
    Newton(ScriptFile,hfssExePath,PrjFile,DesignName,SetupName,...
    Variable,VRange,GoalValue,PlotName,CsvFile,ModName,Material)
%Optimization the Vararibale within range of VRange
%The goalValue is db value of S11 at resonance frequency
%Parameters
%@Variable: variable to be optimized
%@VRange: variable range to be optimized in
%@GoalVar: objective variable
%@GoalValue: value of objective variable
% Optimization stop conditions.
Dir = 'C:\SimDirect\HFSS\Perturbation';


hasConverged = false;     % converge status
Min = VRange(1,1);
Max = VRange(1,2);
if Min > Max
    error('Range values confict!!!!');
end
delta = 0.5;
fprintf('### The loop will run with delta: %.3f mm ###.\n',...
    delta);
MaxStep = 6;
NewValue = Min;

for iIters = 1:MaxStep
    if NewValue <= Max
        if NewValue == -Inf
            NewValue = Min+1;
        end
        fprintf('Running Newton step #%d.........\n', iIters);
        fprintf(['The new estimated value of ',Variable,' is %.3f mm\n'],...
            NewValue);
        try
            [Rf,dBmag] = HFSS(ScriptFile,hfssExePath,...
                PrjFile,DesignName,SetupName,Variable,NewValue,...
                ModName,Material,PlotName,CsvFile );
        catch
            continue;
        end
        fprintf('The new result is %.3f.\n', dBmag);
        
        
        %Estimate if the requirement has been met
        if dBmag <= GoalValue
            hasConverged = true;
            disp('Required Goal is met!');
            fprintf('Optimized Variable is %.3f mm.\n',NewValue);
            OValue = NewValue;
            OMag = dBmag;
            Rfreq = Rf;
            break;
        end
        if NewValue + delta < Max
            disp(['Updating the value of ',Variable,'.......']);
            try
                [~,TmpMag] = HFSS(ScriptFile,hfssExePath,...
                    PrjFile,DesignName,SetupName,Variable,NewValue+delta,...
                    ModName,Material,PlotName,CsvFile );
            catch
                continue;
            end
            if TmpMag <= GoalValue
                fprintf('The new result is %.3f.\n', TmpMag);
                hasConverged = true;
                disp('Required Goal is met!');
                fprintf('Optimized Variable is %.3f mm.\n',NewValue);
                OValue = NewValue;
                OMag = dBmag;
                Rfreq = Rf;
                break;
            end
            k = (TmpMag-dBmag)/delta;
            NewValue = (GoalValue-TmpMag)/k + NewValue+delta;
        else
            disp('Maximum length reached,optimization stoped!');
            break;
        end
    else
        disp('Maximum length reached,optimization stoped!');
        break;
        %slope
    end
    
end
%DataFile = [Direct, '\tmpData', num2str(iIters), '.m'];
% The data items are in the f, S, Z variables now.
% Plot the data.
%disp('Solution Completed. Plotting Results for this iteration...');
%figure(1);
%hold on; grid on;
% plot(f/1e9, LomgS, pltCols(mod(iIters, nCols) + 1));
%hold on;
%xlabel('Frequency (GHz)');
%ylabel('S_{12} (dB)');
%axis([fLow/1e9, fHigh/1e9, -50, 0]);
if (~hasConverged)
    disp('Max Steps exceeded. Optimization did NOT converge .....');
    %fprintf('...The current  #%d...\n', iIters);
    delete([Dir, '\*.csv']);
end

disp('');
disp('');

end