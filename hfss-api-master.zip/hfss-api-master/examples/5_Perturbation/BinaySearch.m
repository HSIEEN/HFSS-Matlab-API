% Description:
% ------------
% A simple example to demonstrate the HFSS-MATLAB-API. This script
% optimizes a dipole antenna design to resonate at a specified frequency.
% The initial length of the dipole is taken to be half the wavelength and
% is optimized so that the simulated resonance frequency and the desired
% resonance frequency are close.

clc; clear variables; close all;

% Add paths to the required m-files.
% Add paths to the required m-files.
addpath('C:\Program Files\MATLAB\R2014a\bin\hfss-api-master\'); % add manually the API root directory.
hfssIncludePaths('C:\Program Files\MATLAB\R2014a\bin\hfss-api-master\');
% Temporary Files. These files can be deleted after the optimization
% is complete. We have to specify the complete path for all of them.
% With pwd we save them in the current directory.
Dir='C:\SimDirect\HFSS\Perturbation';
PrjFile     = [Dir, '\Perturbation-Rectanglar.hfss'];
%DataFile   = [Direct, '\tmpData.m'];
CsvFile     = [Dir, '\tmpCsv'];
ScriptFile  = [Dir, '\Perturbation-Rectanglar.vbs'];
% HFSS Executable Path.
hfssExePath = 'C:\Program Files\AnsysEM\HFSS15.0\Win64\hfss.exe';

%Set  frequency
fLow  = 2.5;%GHz
fHigh = 2.6;%GHz
fC    = 2.5781;%GHz
%Sample materials cell
Material={'Teflon (tm)','Krempel Akaflex PCL (tm)','FR4_epoxy',...
    'Rogers TMM 4 (tm)','Rogers TMM 6 (tm)'};
%The resonance frequency at current value
fActual = 2.5;%GHz

% Plot Colors.
%pltCols = ['b', 'r', 'k', 'g', 'm', 'c', 'y'];
%nCols = length(pltCols);
% Optimization stop conditions.
maxIters     = 15;        % max # of iterations.
Accuracy     = 8e-5;      % accuracy required .
hasConverged = false; % converge status
%IsMonotonicIncreasing; %Binary search direction
%for iMaterias=1:5
%delelte all hfss lock files
delete([Dir, '\*.lock']);
delete([Dir, '\*.auto']);
for iMaterial=1:length(Material)
    %Set varibles of Binary search
    Max = 25;
    Min = 10;
    Mid = (Max+Min)/2;
    fprintf('######  The Material is %s  ######\n', Material{iMaterial});
    
    for iIters = 0:maxIters
        fprintf('Running iteration #%d.........\n', iIters);
        if iIters == 0
            fprintf('Simulation without retunning on progress.......\n');
        else
            fprintf('The new estimated variable is %.3f mm\n', Mid);
        end
        %disp('Creating the Script File...');
        % Create a new temporary HFSS script file.
        fid = fopen(ScriptFile, 'wt');
        % Open a project and set a design active.
        hfssOpenProject(fid,PrjFile);
        hfssSetDesign(fid, 'PostTest');
        if iIters == 0
            hfssVariableChange(fid, 'Hmpost', Min, 'mm');
        else
            hfssVariableChange(fid, 'Hmpost', Mid, 'mm');
        end
        %set diameter of Post
        %hfssVariableChange(fid, 'Rpost',5, 'mm');
        hfssAssignMaterial(fid, 'Post_1', Material{iMaterial});
        % Save the project to a temporary file and solve it.
        hfssSaveProject(fid, PrjFile, true);
        hfssSolveSetup(fid, 'Setup1');
        hfssExportToFile(fid, 'S12Plot', CsvFile, 'csv')
        % Export the Network data as an m-file.
        %hfssExportNetworkData(fid, DataFile, 'Setup1', ...
        %    'Sweep');
        
        % Close the HFSS Script File.
        fclose(fid);
        
        % Execute the Script by starting HFSS.
        %disp('Solving using HFSS...');
        hfssExecuteScript(hfssExePath, ScriptFile);
        
        % Load the data by running the exported matlab file.
        %run(DataFile);
        %if *.csv does not exist, keep running the loop
        try
            tmpData = csvread([CsvFile,'.csv'],1,0);
        catch
            continue
        end
        f       = tmpData(:,1);
        S       = tmpData(:,2);
        %DataFile = [Direct, '\tmpData', num2str(iIters), '.m'];
        % The data items are in the f, S, Z variables now.
        % Plot the data.
        %disp('Solution Completed. Plotting Results for this iteration...');
        %figure(1);
        %hold on; grid on;
        % plot(f/1e9, LogS, pltCols(mod(iIters, nCols) + 1));
        %hold on;
        %xlabel('Frequency (GHz)');
        %ylabel('S_{12} (dB)');
        %axis([fLow/1e9, fHigh/1e9, -50, 0]);
        
        % Find the Resonance Frequency.
        if iIters == 0
            %use move instead of write to save the precision
            copyfile([CsvFile,'.csv'],[Dir,'\SimulatedData\',...
                'No-retunning_',Material{iMaterial},'.csv']);
            delete([Dir, '\*.csv']);
            %csvwrite([Direct,'\SimultedData\','Nonretunning_',...
            % Material{iMaterial},'.csv'],[f,S]);
        else
            [Smax, iMax] = max(S);
            fActual = f(iMax);
            fprintf('Simulated Resonance Frequency: %.4f GHz\n', fActual);
            
            % Check if the required accuracy is met.
            if (abs((fC - fActual)/fC) < Accuracy)
                disp('Required Accuracy is met!');
                fprintf('Optimized Varible is %.3f mm.\n', Mid);
                hasConverged = true;
                copyfile([CsvFile,'.csv'],[Dir,'\SimulatedData\',...
                    'Retunning_',Material{iMaterial},'.csv']);
                delete([Dir, '\*.csv']);
                
                break;
            end
            
            % Binary Search update
            if fActual<fC
                Min = Mid;
                Mid = (Mid+Max)/2;
            else
                Max = Mid;
                Mid = (Mid+Min)/2;
            end
            
            % Loop all over again ...
            disp('Required accuracy not yet met ...');
            
        end
    end
    if (~hasConverged)
        disp('Max Iterations exceeded. Optimization did NOT converge .....');
        %fprintf('...The current  #%d...\n', iIters);
        delete([Dir, '\*.csv']);
    end
end
disp('');
disp('');

% Remove all the added paths.
hfssRemovePaths('C:\Program Files\MATLAB\R2014a\bin\hfss-api-master\');
rmpath('C:\Program Files\MATLAB\R2014a\bin\hfss-api-master\');