function [ fActual,dBmag ] = HFSS(ScriptFile,ExePath,ProjectName,...
    DesignName,SetupName,VarName,Value,ModName,Material,PlotName,CsvFile )

%##########################################
% @ScriptFile: VBS ScriptFile path
% @ExePath:  HFSS.exe path
% @ProjectName:  HFSS project path
% @DesignName: HFSS design path
% @VarName: the variable name
% @Value: the value of the variable
% @ModName: the name of  model of which material to be changed
% @Material: New assigned material for the ModName
% @PlotName: the plot to be exported
% @CsvName: the csv file to be written with plot data
%########################################
addpath('C:\Program Files\MATLAB\R2014a\bin\hfss-api-master\');
%sweep setup
fStartGHz = 2.54;
fStopGHz = 2.58;
fStepMHz = 0.005;
SweepName = 'Sweep';


fid = fopen(ScriptFile, 'wt');
% Open a project and set a design active.
hfssOpenProject(fid,ProjectName);
hfssSetDesign(fid, DesignName);

hfssVariableChange(fid,VarName, Value, 'mm');
hfssAssignMaterial(fid,ModName, Material);
% Save the project to a temporary file and solve it.
Points = hfssEditFrequency(fid,SetupName,SweepName,fStartGHz,...
    fStopGHz,fStepMHz);
hfssSaveProject(fid, ProjectName, true);
hfssSolveSetup(fid, SetupName);
%export data to file
Token = CsvFile(1:end-4);
hfssExportToFile(fid, PlotName, Token, 'csv')
% Export the Network data as an m-file.
fclose(fid);
hfssExecuteScript(ExePath, ScriptFile);
try
    tmpData = csvread(CsvFile,1,0);
catch
    error('Csvfile not exists!!!');
end
f       = tmpData(1:Points,1);
S       = tmpData(1:Points,2);
[~, iMax] = min(S);
fActual = f(iMax);
dBmag = S(iMax);
%fprintf('Simulated Resonance Frequency: %.4f GHz\n', fActual);
end

